const SHEET_URL='https://docs.google.com/spreadsheets/d/e/2PACX-1vS169Srv3rdFs6JAfzotcL9qklXPh0AKi6jt-2ROYDlYSKtdDJy2KQ0znqTfHF_IVCtLJjyXXdbnLbm/pub?gid=463015523&single=true&output=csv';
function load(){Papa.parse(SHEET_URL+'?t='+Date.now(),{download:true,header:true,skipEmptyLines:true,
complete:r=>{let total=r.data.length,refund=0,pending=0;
r.data.forEach(x=>{if((x['PENANGANAN']||'').toUpperCase()==='REFUND')refund++;else pending++;});
totalRefund.textContent=total;refundKirimUlang.textContent=refund;refundBelumKirim.textContent=pending;
lastUpdate.textContent='Update: '+new Date().toLocaleString('id-ID');},
error:e=>lastUpdate.textContent='Gagal membaca Google Sheet';});}
load();setInterval(load,60000);